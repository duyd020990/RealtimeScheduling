// DataGenerator.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "string"
#include <random>
#include <conio.h>
#include <iomanip>
#include <fstream>

int main()
{
	const int cap = 1; // capacity of the system (the number of processor)
	const int nintervals = 20; // number of intervals (maximum number of tasks)

	//Generate the Utilization
	std::default_random_engine generator; // a random generator
	std::exponential_distribution<double> utildis(1.0);
	double p[nintervals] = {}; // temperary utilization
	double util[5][nintervals]; // recode of utilization (the first demension of 5 correspoding to: 60%, 70%, 80%, 90% and 100%)
	int i;
	double num;
	double sum, temp_sum;
	for (int k = 0; k < 5; k++) // k corresponds to each utilization interval: k=0 -> 60%, k=1 -> 70%, .. and so on.
	{
		i = 0;
		sum = 0;
		temp_sum = 0;
		while (i < nintervals) // i correspods to each task
		{
			num = utildis(generator);
			if (num >= 0.1 && num <= 0.3) // here we just limit the acceptable utilization among 0.1 to 0.3 in order to increase the number of tasks
			{                             // If we accept a larger utilization, then the number of tasks is just a few.
				num = ceil(num * 10) / 10; // For convenience of multiprocessor scheduling, the utilizations are expected to be rounded, example: 0.1, 0.2, ... and so on.
				temp_sum = sum + num;      // temporary sum of utilization
				if (temp_sum > cap * 0.6 + cap * 0.1*k) // if sum of utilization exceeds the expected total utilization (for example: 60% of processor capacity)
				{                                       // then the total utilization is set to the exepected one.
					p[i] = (cap * 0.6 + cap * 0.1*k) - sum;
					sum = cap * 0.6 + cap * 0.1*k;
					break;
				}
				p[i] = num;
				sum = temp_sum;
				if (sum == cap * 0.6 + cap * 0.1*k) // if the total utilization is equal to the expected one, then we stop generating tasks
					break;
				i++;
			}
		}
		// copy the temporary utilizations to the record of utilization
		for (int l = 0; l < nintervals; l++)
		{
			util[k][l] = p[l];
		}
	}
	// print the generated utilizations to the terminal screen
	std::cout << "Utilization:  " << std::endl;
	for (int i = 0; i < 5; i++)
	{
		std::cout << 60+i*10 <<"%:" << std::endl;
		std::cout << "1: ";
		for (int j = 0; j < nintervals; j++)
		{
			std::cout << util[i][j] << "  ";
		}
		std::cout << std::endl;
	}
	
	//Generate WCET
	std::uniform_int_distribution<int> wcetdis(1, 20); // Wcet is generated using an uniform distribution
	int wcet[5][nintervals];                           // We here limit the wcet to be integer numbers lower than 20
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < nintervals; j++)
		{
			if (util[i][j] > 0)
				wcet[i][j] = wcetdis(generator);
			else
				wcet[i][j] = 0;
		}
	}
	// print the generated wcet to the terminal screen
	std::cout << "WCET:  " << std::endl;
	for (int i = 0; i < 5; i++)
	{
		std::cout << 60 + i * 10 << "%:" << std::endl;
		std::cout << "1: ";
		for (int j = 0; j < nintervals; j++)
		{
			std::cout << wcet[i][j] << "  ";
		}
		std::cout << std::endl;
	}
	
	// Similarly to WCET, we can generate ET and period
	//Generate ET
	int et[5][nintervals];
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < nintervals; j++)
		{
			if (util[i][j] > 0)
			{
				std::uniform_int_distribution<int> etdis(1, wcet[i][j]);
				et[i][j] = etdis(generator);
			}
			else
				et[i][j] = 0;
			
		}
	}
	// print the generated ET to the terminal screen
	std::cout << "ET:  " << std::endl;
	for (int i = 0; i < 5; i++)
	{
		std::cout << 60 + i * 10 << "%:" << std::endl;
		std::cout << "1: ";
		for (int j = 0; j < nintervals; j++)
		{
			std::cout << et[i][j] << "  ";
		}
		std::cout << std::endl;
	}

	//Generate Period
	int period[5][nintervals];
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < nintervals; j++)
		{
			if (util[i][j] > 0)
				period[i][j] = std::ceil(wcet[i][j] / util[i][j]);
			else
				period[i][j] = 0;
		}
	}
	// print the generated period to the terminal screen
	std::cout << "Period:  " << std::endl;
	for (int i = 0; i < 5; i++)
	{
		std::cout << 60 + i * 10 << "%:" << std::endl;
		std::cout << "1: ";
		for (int j = 0; j < nintervals; j++)
		{
			std::cout << period[i][j] << "  ";
		}
		std::cout << std::endl;
	}

	
	// Create output data
	std::ofstream outputfile;
	outputfile.open("periodic.cfg.1-60");
	outputfile<< "\#Target Periodic Utilization = 60.00" << std::endl;
	outputfile<< "\#tid\twcet\tet\tprd\treq_tim" << std::endl;
	for (int i = 0; i < nintervals; i++)
	{
		if (util[0][i] > 0)
		{
			for (int k = 0; k*period[0][i] < 1000; k++)
			{
				outputfile << i << "\t" << wcet[0][i] << "\t" << et[0][i] << "\t" << period[0][i] << "\t" << k*period[0][i] << std::endl;
			}
		}
	}
	outputfile.close();

	outputfile.open("periodic.cfg.16-70");
	outputfile << "\#Target Periodic Utilization = 70.00" << std::endl;
	outputfile << "\#tid\twcet\tet\tprd\treq_tim" << std::endl;
	for (int i = 0; i < nintervals; i++)
	{
		if (util[1][i] > 0)
		{
			for (int k = 0; k*period[1][i] < 1000; k++)
			{
				outputfile << i << "\t" << wcet[1][i] << "\t" << et[1][i] << "\t" << period[1][i] << "\t" << k*period[1][i] << std::endl;
			}
		}
	}
	outputfile.close();

	outputfile.open("periodic.cfg.1-80");
	outputfile << "\#Target Periodic Utilization = 80.00" << std::endl;
	outputfile << "\#tid\twcet\tet\tprd\treq_tim" << std::endl;
	for (int i = 0; i < nintervals; i++)
	{
		if (util[2][i] > 0)
		{
			for (int k = 0; k*period[2][i] < 1000; k++)
			{
				outputfile << i << "\t" << wcet[2][i] << "\t" << et[2][i] << "\t" << period[2][i] << "\t" << k*period[2][i] << std::endl;
			}
		}
	}
	outputfile.close();
	outputfile.open("periodic.cfg.1-90");
	outputfile << "\#Target Periodic Utilization = 90.00" << std::endl;
	outputfile << "\#tid\twcet\tet\tprd\treq_tim" << std::endl;
	for (int i = 0; i < nintervals; i++)
	{
		if (util[3][i] > 0)
		{
			for (int k = 0; k*period[3][i] < 1000; k++)
			{
				outputfile << i << "\t" << wcet[3][i] << "\t" << et[3][i] << "\t" << period[3][i] << "\t" << k*period[3][i] << std::endl;
			}
		}
	}
	outputfile.close();
	outputfile.open("periodic.cfg.1-100");
	outputfile << "\#Target Periodic Utilization = 100.00" << std::endl;
	outputfile << "\#tid\twcet\tet\tprd\treq_tim" << std::endl;
	for (int i = 0; i < nintervals; i++)
	{
		if (util[4][i] > 0)
		{
			for (int k = 0; k*period[4][i] < 1000; k++)
			{
				outputfile << i << "\t" << wcet[4][i] << "\t" << et[4][i] << "\t" << period[4][i] << "\t" << k*period[4][i] << std::endl;
			}
		}
	}
	outputfile.close();
	

	std::cout << "end!" << std::endl;
	getch();
	return 0;
}

